<#ftl output_format="plainText">
${msg("emailTestBody", realmName, user.getFirstName())}