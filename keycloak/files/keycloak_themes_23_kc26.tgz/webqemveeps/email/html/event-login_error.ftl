<#include "wq-template-top.ftl">
${kcSanitize(msg("eventLoginErrorBodyHtml",event.date,event.ipAddress,user.getFirstName()))?no_esc}
<#include "wq-template-bot.ftl">