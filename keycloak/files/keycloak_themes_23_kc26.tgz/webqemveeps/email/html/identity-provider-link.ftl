<#include "wq-template-top.ftl">
${kcSanitize(msg("identityProviderLinkBodyHtml", identityProviderAlias, realmName, identityProviderContext.username, link, linkExpiration, linkExpirationFormatter(linkExpiration),user.getFirstName()))?no_esc}
<#include "wq-template-bot.ftl">