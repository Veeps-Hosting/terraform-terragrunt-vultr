<#include "wq-template-top.ftl">
${kcSanitize(msg("emailVerificationBodyCodeHtml",code,user.getFirstName()))?no_esc}
<#include "wq-template-bot.ftl">