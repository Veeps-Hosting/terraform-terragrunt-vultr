<#include "wq-template-top.ftl">
${kcSanitize(msg("eventRemoveTotpBodyHtml",event.date, event.ipAddress,user.getFirstName()))?no_esc}
<#include "wq-template-bot.ftl">