<#include "wq-template-top.ftl">
${kcSanitize(msg("passwordResetBodyHtml",link, linkExpiration, realmName, linkExpirationFormatter(linkExpiration),user.getFirstName()))?no_esc}
<#include "wq-template-bot.ftl">