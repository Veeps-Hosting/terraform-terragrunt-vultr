<#include "wq-template-top.ftl">
${kcSanitize(msg("emailTestBodyHtml",realmName, user.getFirstName()))?no_esc}
<#include "wq-template-bot.ftl">